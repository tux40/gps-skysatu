
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-3" style="padding: 0 0 40vh;">
            <div class="card mx-4" style="background: rgba(220,220,220,0.7)">
                <div class="card-body p-2">
                    <h1 style="text-align: center; margin-bottom: 0"><?php echo e(trans('panel.site_title')); ?></h1>
                    <h5 style="text-align: center; font-weight: lighter; margin-bottom: 15px"><?php echo e(trans('panel.site_subtitle')); ?></h5>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-user" style="width:  9px"></i>
                            </span>
                            </div>
                            <input id="username" name="username" type="text"
                                   class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" required
                                   autocomplete="username" autofocus placeholder="<?php echo e(trans('global.login_username')); ?>"
                                   value =""> <!--value="<?php echo e(old('username', null)); ?>"-->
                            <?php if($errors->has('username')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('username')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="input-group mb-2">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-lock"></i></span>
                            </div>

                            <input id="password" name="password" type="password"
                                   class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" required
                                   placeholder="<?php echo e(trans('global.login_password')); ?>">

                            <?php if($errors->has('password')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('password')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="input-group mb-2">
                            <div class="form-check checkbox">
                                <input class="form-check-input" name="remember" type="checkbox" id="remember"
                                       style="vertical-align: middle;"/>
                                <label class="form-check-label" for="remember" style="vertical-align: middle; font-weight: 500; color: #000;">
                                    <?php echo e(trans('global.remember_me')); ?>

                                </label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12" style="text-align: center;">
                                <button type="submit" class="btn btn-primary col-4 px-3">
                                    <?php echo e(trans('global.login')); ?>

                                </button>
                            </div>








                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/skysatcotest/skysentana/resources/views/auth/login.blade.php ENDPATH**/ ?>