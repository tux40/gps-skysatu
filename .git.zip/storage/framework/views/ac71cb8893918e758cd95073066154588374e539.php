<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(trans('panel.site_title')); ?></title>
    <!--<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"/>-->
   
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet"/>
    <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet"/>
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/buttons.dataTables.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/select.dataTables.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/coreui.min.css')); ?>" rel="stylesheet"/>
  
<script src="https://cdn.jsdelivr.net/npm/@coreui/coreui@4.3.2/dist/js/coreui.bundle.min.js" integrity="sha384-yaqfDd6oGMfSWamMxEH/evLG9NWG7Q5GHtcIfz8Zg1mVyx2JJ/IRPrA28UOLwAhi" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="<?php echo e(asset('css/dropzone.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/custom.css?v=').time()); ?> }}" rel="stylesheet"/>

    <?php echo $__env->yieldContent('styles'); ?>
    <style>
        .select2-results__option[aria-selected=true] {
            display: none;
        }
        body {
            font-family: Roboto, 'Segoe UI', Tahoma, sans-serif !important;
        }
    </style>
    
</head>



<body class="app header-fixed aside-menu-fixed pace-done sidebar-hidden">


<nav>
    <ul class="sidebar ">
        <li onclick=hideSidebar()><a href="#"><svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg></a></li>
        <li><a href="<?php echo e(route("admin.home")); ?>"> <?php echo e(trans('global.dashboard')); ?></a></li>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_access')): ?>
        <li ><a href="<?php echo e(route("admin.ships.index")); ?>"><?php echo e(trans('cruds.ship.title')); ?></a></li> 
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('email_destination_access')): ?>
        <li ><a href="<?php echo e(route("admin.email-destination.index")); ?>">Destination Email</a></li> 
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
        <li >
            <a href="#"><?php echo e(trans('cruds.userManagement.title')); ?></a>
            <ul class="dropdown">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                <li><a href="<?php echo e(route("admin.permissions.index")); ?>"><?php echo e(trans('cruds.permission.title')); ?></a></li>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
               <li><a href="<?php echo e(route("admin.roles.index")); ?>"><?php echo e(trans('cruds.role.title')); ?></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                <li><a href="<?php echo e(route("admin.users.index")); ?>"><?php echo e(trans('cruds.user.title')); ?></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('distributor_access')): ?>
                <li><a href="<?php echo e(route("admin.distributors.index")); ?>"><?php echo e(trans('cruds.distributor.title')); ?></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manager_access')): ?>
                <li><a href="<?php echo e(route("admin.managers.index")); ?>"><?php echo e(trans('cruds.manager.title')); ?></a></li>
                <?php endif; ?>
                <li ><a href="<?php echo e(route("admin.change-password")); ?>">  <?php echo e(trans('cruds.user.fields.change_password')); ?></a></li>
            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_access')): ?>
       
        <li >
            <a href="#"><?php echo e(trans('cruds.setting.title')); ?></a>
            <ul class="dropdown">
                <li><a href="<?php echo e(route("admin.change-timezone")); ?>">Timezone</a></li>
               
            </ul>
        </li>
        <?php endif; ?>
        <li >
            <a href="#" 
               onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                <?php echo e(trans('global.logout')); ?>

            </a>
        </li>
    </ul>
    <ul>
        <li><a href="<?php echo e(route("admin.home")); ?>">  <?php echo e(trans('panel.site_title')); ?></a></li>
        <li class="hideOnMobile"><a href="<?php echo e(route("admin.home")); ?>">  <?php echo e(trans('global.dashboard')); ?></a></li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_access')): ?>
        <li class="hideOnMobile"><a href="<?php echo e(route("admin.ships.index")); ?>"><?php echo e(trans('cruds.ship.title')); ?></a></li> 
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('email_destination_access')): ?>
        <li class="hideOnMobile"><a href="<?php echo e(route("admin.email-destination.index")); ?>">Destination Email</a></li> 
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
        <li class="hideOnMobile">
            <a href="#"><?php echo e(trans('cruds.userManagement.title')); ?></a>
            <ul class="dropdown">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                <li><a href="<?php echo e(route("admin.permissions.index")); ?>"><?php echo e(trans('cruds.permission.title')); ?></a></li>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
               <li><a href="<?php echo e(route("admin.roles.index")); ?>"><?php echo e(trans('cruds.role.title')); ?></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                <li><a href="<?php echo e(route("admin.users.index")); ?>"><?php echo e(trans('cruds.user.title')); ?></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('distributor_access')): ?>
                <li><a href="<?php echo e(route("admin.distributors.index")); ?>"><?php echo e(trans('cruds.distributor.title')); ?></a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manager_access')): ?>
                <li><a href="<?php echo e(route("admin.managers.index")); ?>"><?php echo e(trans('cruds.manager.title')); ?></a></li>
                <?php endif; ?>
                <li class="hideOnMobile"><a href="<?php echo e(route("admin.change-password")); ?>">  <?php echo e(trans('cruds.user.fields.change_password')); ?></a></li>
            </ul>
        </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting_access')): ?>
       
        <li class="hideOnMobile">
            <a href="#"><?php echo e(trans('cruds.setting.title')); ?></a>
            <ul class="dropdown">
                <li><a href="<?php echo e(route("admin.change-timezone")); ?>">Timezone</a></li>
               
            </ul>
        </li>
        <?php endif; ?>
        <li class="hideOnMobile">
            <a href="#" class="nav-link"
               onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                <?php echo e(trans('global.logout')); ?>

            </a>
        </li>
        <li class="menu-button" onclick=showSidebar()><a href="#"><svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/></svg></a></li>
    </ul>
    
</nav>

<div>

    <main class="main">
        <div class="container-fluid">
            <?php if(session('message')): ?>
                <div class="row mb-2">
                    <div class="col-lg-12">
                        <div class="alert alert-success" role="alert"><?php echo e(session('message')); ?></div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($errors->count() > 0): ?>
                <div class="alert alert-danger">
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>

        </div>


    </main>
    <form id="logoutform" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>
</div>
<!--<?php echo $__env->make('partials.spinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>-->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!--<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.10.2/umd/popper.min.js"></script>
<script src="<?php echo e(asset('js/coreui.min.js')); ?>"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.select.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-datetimepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dropzone.min.js')); ?>"></script>
<!--<script src="<?php echo e(asset('js/bootstrap-tagsinput.js')); ?>"></script>-->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script>
    $(function () {
        let copyButtonTrans = '<?php echo e(trans('global.datatables.copy')); ?>'
        let csvButtonTrans = '<?php echo e(trans('global.datatables.csv')); ?>'
        let excelButtonTrans = '<?php echo e(trans('global.datatables.excel')); ?>'
        let pdfButtonTrans = '<?php echo e(trans('global.datatables.pdf')); ?>'
        let printButtonTrans = '<?php echo e(trans('global.datatables.print')); ?>'
        let colvisButtonTrans = '<?php echo e(trans('global.datatables.colvis')); ?>'

        let languages = {
            'en': 'https://cdn.datatables.net/plug-ins/1.10.19/i18n/English.json',
            'id': 'https://cdn.datatables.net/plug-ins/1.10.19/i18n/Indonesian.json'
        };

        $.extend(true, $.fn.dataTable.Buttons.defaults.dom.button, {className: 'btn'})
        $.extend(true, $.fn.dataTable.defaults, {
            language: {
                url: languages['<?php echo e(app()->getLocale()); ?>']
            },
            columnDefs: [{
                orderable: false,
                className: 'select-checkbox',
                targets: 0
            }, {
                orderable: false,
                searchable: false,
                targets: -1
            }],
            select: {
                style: 'multi+shift',
                selector: 'td:first-child'
            },
            order: [],
            scrollX: true,
            pageLength: 100,
            dom: 'lBfrtip<"actions">',
            buttons: [
                {
                    extend: 'copy',
                    className: 'btn-default',
                    text: copyButtonTrans,
                    exportOptions: {
                        columns: ':visible'
                    }
                },
                {
                    extend: 'csv',
                    className: 'btn-default',
                    text: csvButtonTrans,
                    exportOptions: {
                        columns: ':visible'
                    }
                },
                {
                    extend: 'excel',
                    className: 'btn-default',
                    text: excelButtonTrans,
                    exportOptions: {
                        columns: ':visible'
                    }
                },
                {
                    extend: 'pdf',
                    className: 'btn-default',
                    text: pdfButtonTrans,
                    exportOptions: {
                        columns: ':visible'
                    }
                },
                {
                    extend: 'print',
                    className: 'btn-default',
                    text: printButtonTrans,
                    exportOptions: {
                        columns: ':visible'
                    }
                },
                {
                    extend: 'colvis',
                    className: 'btn-default',
                    text: colvisButtonTrans,
                    exportOptions: {
                        columns: ':visible'
                    }
                }
            ]
        });

        $.fn.dataTable.ext.classes.sPageButton = '';
    });

</script>
<script>
    $(document).ready(function () {
        $('.searchable-field').select2({
            minimumInputLength: 3,
            ajax: {
                url: '<?php echo e(route("admin.globalSearch")); ?>',
                dataType: 'json',
                type: 'GET',
                delay: 200,
                data: function (term) {
                    return {
                        search: term
                    };
                },
                results: function (data) {
                    return {
                        data
                    };
                }
            },
            escapeMarkup: function (markup) {
                return markup;
            },
            templateResult: formatItem,
            templateSelection: formatItemSelection,
            placeholder: '<?php echo e(trans('global.search')); ?>...',
            language: {
                inputTooShort: function (args) {
                    var remainingChars = args.minimum - args.input.length;
                    var translation = '<?php echo e(trans('global.search_input_too_short')); ?>';

                    return translation.replace(':count', remainingChars);
                },
                errorLoading: function () {
                    return '<?php echo e(trans('global.results_could_not_be_loaded')); ?>';
                },
                searching: function () {
                    return '<?php echo e(trans('global.searching')); ?>';
                },
                noResults: function () {
                    return '<?php echo e(trans('global.no_results')); ?>';
                },
            }

        });

        function formatItem(item) {
            if (item.loading) {
                return '<?php echo e(trans('global.searching')); ?>...';
            }
            var markup = "<div class='searchable-link' href='" + item.url + "'>";
            markup += "<div class='searchable-title'>" + item.model + "</div>";
            $.each(item.fields, function (key, field) {
                markup += "<div class='searchable-fields'>" + item.fields_formated[field] + " : " + item[field] + "</div>";
            });
            markup += "</div>";

            return markup;
        }

        function formatItemSelection(item) {
            if (!item.model) {
                return '<?php echo e(trans('global.search')); ?>...';
            }
            return item.model;
        }

        $(document).delegate('.searchable-link', 'click', function () {
            var url = $(this).attr('href');
            window.location = url;
        });
    });

    $(window).on('load', function(){
        if($('#overlay-box').length > 0) {
            $('#overlay-box').fadeOut('slow', function(){
                $(this).hide()
            });
        }
    });
</script>
<script>
    function showSidebar(){
        const sidebar = document.querySelector('.sidebar')
        sidebar.style.display='flex'
        console.log('masuk')
    }
    function hideSidebar(){
        const sidebar = document.querySelector('.sidebar')
        sidebar.style.display='none'
    }
</script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\Users\me\Desktop\!Mbuhhhhh\sky1mas-test\resources\views/layouts/admin.blade.php ENDPATH**/ ?>