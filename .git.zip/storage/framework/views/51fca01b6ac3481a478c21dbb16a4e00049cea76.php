
<?php $__env->startSection('content'); ?>
    <!--<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_create')): ?>
        <div style="margin-bottom: 10px;" class="row">
            <div class="col-lg-12">
                <a class="btn btn-success" href="<?php echo e(route("admin.ships.create")); ?>">
                    <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.ship.title_singular')); ?>

                </a>
            </div>
        </div>
    <?php endif; ?>--><br>
    <div class="card">
        <div class="card-header">
            <?php echo e(trans('cruds.ship.title_singular')); ?> <?php echo e(trans('global.list')); ?>

        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-Ship">
                    <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.ship.fields.id')); ?>

                        </th>
                        <th style="min-width: 200px;"> &nbsp;</th>

                        <th style="min-width: 102px;">
                            <?php echo e(trans('cruds.ship.fields.ship_ids')); ?>

                        </th>
                        <th style="min-width: 70px">
                            <?php echo e(trans('cruds.ship.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.ship.fields.call_sign')); ?>

                        </th>
                        <th>
                            Send To Pertamina
                        </th>
                        <th style ="min-width:150px;">
                            <?php echo e(trans('cruds.ship.fields.owner')); ?>

                        </th>

                        <th style="min-width: 100px;">
                            Last Sent Time
                        </th>

                        <th width="150">
                            Last Sent Destination
                        </th>

                        <th style="min-width: 100px;">
                            Last Sent Status
                        </th>

                        <!--<th width="40">
                            <?php echo e(trans('cruds.ship.fields.region_name')); ?>

                        </th>
                        <th style="min-width: 120px;">
                            <?php echo e(trans('cruds.ship.fields.last_registration_utc')); ?>

                        </th>

                        <th>
                            <?php echo e(trans('cruds.ship.fields.type')); ?>

                        </th>-->
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $ships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($ship->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($ship->id ?? ''); ?>

                            </td>
                            <td style="text-align: center;">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_show')): ?>
                                    <a class="btn btn-xs btn-success" href="<?php echo e(route('admin.ships.show', $ship->id)); ?>">
                                        <?php echo e(trans('global.go_to_table')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_ptp')): ?>
                                   <a class="btn btn-xs btn-danger" href="<?php echo e(route('admin.ships.ptps', $ship->id)); ?>" style="color: #fff;">
                                        PTP
                                   </a>
                                <?php endif; ?>

                                <!--<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_delete')): ?>
                                    <form action="<?php echo e(route('admin.ships.destroy', $ship->id)); ?>" method="POST"
                                          onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');"
                                          style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger"
                                               value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>-->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_logs')): ?>
                                    <a class="btn btn-xs btn-warning" href="<?php echo e(route('admin.ships.logs', $ship->id)); ?>" style="color: #fff;">
                                        Logs
                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_edit')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.ships.edit', $ship->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                            </td>
                            <td>
                                <?php echo e($ship->ship_ids ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($ship->name ?? ''); ?>

                            </td>
                            <td style="text-align: center;">
                                <?php echo e($ship->call_sign ?? ''); ?>

                            </td>
                            <td style="text-align: center;">
                                <?php echo e($ship->send_to_pertamina == 1 ? 'Enabled' :  'Disabled'); ?>

                                <!--<?php echo e($ship->send_to_pertamina == 1 ? 'Disabled' :  'Enabled'); ?>-->
                            </td>
                            <td>
                                <?php echo e($ship->owner ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($ship->emailSendPertaminaLast()->created_at ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($ship->emailSendPertaminaLast()->last_sent_destination ?? ''); ?>

                            </td>
                            <td style="text-align: center;">
                                <?php echo e($ship->emailSendPertaminaLast()->last_sent_status ?? ''); ?>

                            </td>
                            <!--<td>
                                <?php echo e($ship->region_name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($ship->last_registration_utc ?? ''); ?>

                            </td>

                            <td>
                                <?php echo e(App\Ship::TYPE_SELECT[$ship->type] ?? ''); ?>

                            </td>-->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        $(function () {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ship_delete')): ?>
            let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
            let deleteButton = {
                text: deleteButtonTrans,
                url: "<?php echo e(route('admin.ships.massDestroy')); ?>",
                className: 'btn-danger',
                action: function (e, dt, node, config) {
                    var ids = $.map(dt.rows({selected: true}).nodes(), function (entry) {
                        return $(entry).data('entry-id')
                    });

                    if (ids.length === 0) {
                        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

                        return
                    }

                    if (confirm('<?php echo e(trans('global.areYouSuredeleteterminal')); ?>')) {
                        $.ajax({
                            headers: {'x-csrf-token': _token},
                            method: 'POST',
                            url: config.url,
                            data: {ids: ids, _method: 'DELETE'}
                        })
                            .done(function () {
                                location.reload()
                            })
                    }
                }
            }
            dtButtons.push(deleteButton)
            <?php endif; ?>

            $.extend(true, $.fn.dataTable.defaults, {
                order: [[1, 'desc']],
                pageLength: 100,
                select: {
                //style:    'multi',
                style:    'single',
                selector: 'td:first-child'
                }
            });
            $('.datatable-Ship:not(.ajaxTable)').DataTable({buttons: dtButtons})
            $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/skysatcotest/skysentana/resources/views/admin/ships/index.blade.php ENDPATH**/ ?>