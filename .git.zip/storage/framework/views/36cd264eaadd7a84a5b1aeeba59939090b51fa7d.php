
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.ship.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" autocomplete="off" action="<?php echo e(route("admin.ships.update", [$ship->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="ship_ids"><?php echo e(trans('cruds.ship.fields.ship_ids')); ?></label>
            <div class="form-group">
            <?php if(strpos($ship->ship_ids, "-")): ?>
                <input class="form-control <?php echo e($errors->has('ship_ids') ? 'is-invalid' : ''); ?>" type="text" name="ship_ids" id="ship_ids" value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>" required style="width: 30%;" readonly="true">
            <?php else: ?>
                <input class="form-control <?php echo e($errors->has('ship_ids') ? 'is-invalid' : ''); ?>" type="text" name="ship_ids" id="ship_ids" value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>" required style="width: 30%; float: left;" readonly="true">
                <select name="ship_ids" class="form-control" value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>" style="width: 10%;">
                      <option selected disabled>ADD ID</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-A">A</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-B">B</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-C">C</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-D">D</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-E">E</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-F">F</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-G">G</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-H">H</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-I">I</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-J">J</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-K">K</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-L">L</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-M">M</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-N">N</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-O">O</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-P">P</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-Q">Q</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-R">R</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-S">S</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-T">T</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-U">U</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-V">V</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-W">W</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-X">X</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-Y">Y</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>-Z">Z</option>
                      <option value="<?php echo e(old('ship_ids', $ship->ship_ids)); ?>">NONE</option>
                </select>
            <?php endif; ?>
            </div>
                <?php if($errors->has('ship_ids')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('ship_ids')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.ship_ids_helper')); ?></span>
            </div>

            <div class="form-group">
                <!--<label class="required" for="name"><?php echo e(trans('cruds.ship.fields.name')); ?></label>-->
                <label  for="name"><?php echo e(trans('cruds.ship.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $ship->name)); ?>">
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.name_helper')); ?></span>
            </div>
            <!--<div class="form-group">
                <label for="name"><?php echo e(trans('cruds.ship.fields.call_sign')); ?></label>
                <input class="form-control <?php echo e($errors->has('call_sign') ? 'is-invalid' : ''); ?>" type="text" name="call_sign" id="call_sign" value="<?php echo e(old('call_sign', $ship->call_sign)); ?>">
                <?php if($errors->has('call_sign')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('call_sign')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.call_sign_helper')); ?></span>
            </div>-->
            <div class="form-group">
                <label for="owner"><?php echo e(trans('cruds.ship.fields.owner')); ?></label>
                <input class="form-control <?php echo e($errors->has('owner') ? 'is-invalid' : ''); ?>" type="text" name="owner" id="owner" value="<?php echo e(old('owner', $ship->owner)); ?>">
                <?php if($errors->has('owner')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('owner')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.owner_helper')); ?></span>
            </div>
            <!--<div class="form-group">
                <label for="region_name"><?php echo e(trans('cruds.ship.fields.region_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('region_name') ? 'is-invalid' : ''); ?>" type="text" name="region_name" id="region_name" value="<?php echo e(old('region_name', $ship->region_name)); ?>">
                <?php if($errors->has('region_name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('region_name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.region_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="last_registration_utc"><?php echo e(trans('cruds.ship.fields.last_registration_utc')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('last_registration_utc') ? 'is-invalid' : ''); ?>" type="text" name="last_registration_utc" id="last_registration_utc" value="<?php echo e(old('last_registration_utc', $ship->last_registration_utc)); ?>">
                <?php if($errors->has('last_registration_utc')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('last_registration_utc')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.last_registration_utc_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="long"><?php echo e(trans('cruds.ship.fields.long')); ?></label>
                <input class="form-control <?php echo e($errors->has('long') ? 'is-invalid' : ''); ?>" type="text" name="long" id="long" value="<?php echo e(old('long', $ship->long)); ?>">
                <?php if($errors->has('long')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('long')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.long_helper')); ?></span>
            </div>-->

            <div class="form-group">
                <label for="last_registration_utc">Call Sign</label>
                <input class="form-control <?php echo e($errors->has('call_sign') ? 'is-invalid' : ''); ?>" type="text" name="call_sign" id="call_sign" value="<?php echo e(old('call_sign', $ship->call_sign)); ?>">
                <?php if($errors->has('call_sign')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('call_sign')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.last_registration_utc_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="last_registration_utc">Send To Pertamina</label>
                <input class="<?php echo e($errors->has('send_to_pertamina') ? 'is-invalid' : ''); ?>" type="radio" name="send_to_pertamina" value="1" <?php if($ship->send_to_pertamina == 1): ?> checked <?php endif; ?>> Enable
                <input class="<?php echo e($errors->has('send_to_pertamina') ? 'is-invalid' : ''); ?>" type="radio" name="send_to_pertamina" value="0" <?php if($ship->send_to_pertamina == 0): ?> checked <?php endif; ?>> Disable
                <?php if($errors->has('call_sign')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('call_sign')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.last_registration_utc_helper')); ?></span>
            </div>

            <div class="form-group">
                <label for="last_registration_utc">Destination Email</label>
                <input class="form-control <?php echo e($errors->has('additional_email_ship') ? 'is-invalid' : ''); ?>" type="text" name="additional_email_ship" id="call_sign" value="<?php echo e($ship->additional_email_ship ?? str_replace(',', ";",str_replace('"', "",str_replace("]", "",str_replace("[", "",json_encode(\App\EmailDestination::pluck('email')->toArray())))))); ?>">
                <span>(Gunakan tanda titik koma(;) sebagai pemisah)</span>
                <?php if($errors->has('call_sign')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('call_sign')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.last_registration_utc_helper')); ?></span>
            </div>

           <!-- <div class="form-group">
                <label><?php echo e(trans('cruds.ship.fields.type')); ?></label>
                <select class="form-control <?php echo e($errors->has('type') ? 'is-invalid' : ''); ?>" name="type" id="type">
                    <option value disabled <?php echo e(old('type', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Ship::TYPE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('type', $ship->type) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.ship.fields.type_helper')); ?></span>
            </div>-->

            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skysatcotest/skysentana/resources/views/admin/ships/edit.blade.php ENDPATH**/ ?>