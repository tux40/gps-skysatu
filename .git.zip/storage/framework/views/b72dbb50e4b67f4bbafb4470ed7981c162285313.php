<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            Changed TimeZone
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route("admin.store-timezone")); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Select TimeZone</label>
                    <select class="form-control <?php echo e($errors->has('timezone') ? 'is-invalid' : ''); ?>" name="timezone" id="timezone">
                        <option value disabled <?php echo e(old('timezone', null) === null ? 'selected' : ''); ?>>Select TimeZone</option>
                        <?php $__currentLoopData = App\user::TIMEZONE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e(old('timezone', $user->timezone) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('timezone')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('timezone')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.ship.fields.type_helper')); ?></span>
                </div>
                <div class="form-group">
                    <button class="btn btn-danger" type="submit">
                        Update TimeZone
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\me\Desktop\!Mbuhhhhh\sky1mas\resources\views/admin/users/change-timezone.blade.php ENDPATH**/ ?>