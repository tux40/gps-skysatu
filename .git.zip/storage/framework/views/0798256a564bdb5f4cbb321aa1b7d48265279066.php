
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <?php echo e(trans('cruds.user.fields.change_password')); ?>

        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route("admin.store-password")); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="required" for="old_password"><?php echo e(trans('cruds.user.fields.old_password')); ?></label>
                    <input class="form-control <?php echo e($errors->has('old_password') ? 'is-invalid' : ''); ?>" type="password" name="old_password" id="old_password" required>
                    <?php if($errors->has('old_password')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('old_password')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.user.fields.password_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label class="required" for="password"><?php echo e(trans('cruds.user.fields.new_password')); ?></label>
                    <input class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" type="password" name="password" id="password" required>
                    <?php if($errors->has('password')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('password')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.user.fields.password_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label class="required" for="password_confirmation"><?php echo e(trans('cruds.user.fields.confirm_password')); ?></label>
                    <input class="form-control <?php echo e($errors->has('password_confirmation') ? 'is-invalid' : ''); ?>" type="password" name="password_confirmation" id="password_confirmation" required>
                    <?php if($errors->has('password_confirmation')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('password_confirmation')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.user.fields.password_helper')); ?></span>
                </div>
                <div class="form-group">
                    <button class="btn btn-danger" type="submit">
                        <?php echo e(trans('global.save')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/skysatcotest/skysentana/resources/views/admin/users/change-password.blade.php ENDPATH**/ ?>