
<?php $__env->startSection('content'); ?>
<div class="card" style="margin-top: 20px;">
    <div class="card-header" style="padding: 20px; font-size: 18px; font-weight: 700;">
        Database - <?php echo e($ship->ship_ids); ?> <?php echo e($ship->name); ?>

    </div>
    <div class="tab-content">
        <div class="tab-pane" role="tabpanel" id="ship_history_ships" style="padding-top: 20px;">
            
            <?php if ($__env->exists('admin.ships.relationships.shipHistoryShips', ['historyShips' => $ship->shipHistoryShips])) echo $__env->make('admin.ships.relationships.shipHistoryShips', ['historyShips' => $ship->shipHistoryShips], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/skysatcotest/skysentana/resources/views/admin/ships/show.blade.php ENDPATH**/ ?>