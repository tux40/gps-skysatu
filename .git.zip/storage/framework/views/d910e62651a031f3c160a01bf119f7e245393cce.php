<div id="overlay-box">
        <div class="overlay-wrap">
            <div class="overlay">
                <img src="<?php echo e(asset('images/spinner.gif')); ?>">
                <p>Loading...</p>
            </div>
        </div>
</div>
<?php /**PATH C:\Users\me\Desktop\!Mbuhhhhh\sky1mas\resources\views/partials/spinner.blade.php ENDPATH**/ ?>