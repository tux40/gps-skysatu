
<?php $__env->startSection('content'); ?>
<style>
    #exampleAll_filter {
        display: none;
    }
    .dataTables_length{
        margin-top: -34px;
    }
    div.dt-buttons {
        margin-top: -40px;
    }
    
     #exampleAll_wrapper {
        display: none;
    }
</style>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/datetime/1.1.1/css/dataTables.dateTime.min.css">
    <div class="card">
        <div class="card-header">
            Logs List
        </div>
    <div class="tab-content">
      <div class="tab-pane" role="tabpanel" id="logs" style="padding-top: 20px;">
        <div class="card-body">
            <div class="table-responsive">
                <table border="0" cellspacing="5" cellpadding="5" style="float: right;">
                <tbody>
                    <tr>
                        <td style="font-weight: normal;">Tahun dan bulan:</td>
                        <td>
                            <select class="form-control" id="myInput" name="datep">
                            <option value="xxxxxxxxxx"></option>
                            <option value="2022-01-">2022-01</option>    
                            <option value="2022-02-">2022-02</option>
                            <option value="2022-03-">2022-03</option>
                            <option value="2022-04-">2022-04</option>
                            <option value="2022-05-">2022-05</option>
                            <option value="2022-06-">2022-06</option>
                            <option value="2022-07-">2022-07</option>
                            <option value="2022-08-">2022-08</option>
                            <option value="2022-09-">2022-09</option>
                            <option value="2022-10-">2022-10</option>
                            <option value="2022-11-">2022-11</option>
                            <option value="2022-12-">2022-12</option>
                            </select>
                        </td>
                    </tr>
                </tbody>
            </table><br>
                <table class="table table-bordered table-striped table-hover datatable display nowrap" id="exampleAll">
                    <thead>
                    <tr>
                        <th></th>
                        <th>
                            <?php echo e(trans('cruds.ship.fields.id')); ?>

                        </th>
                        <th style="min-width: 70px;">
                            &nbsp;
                        </th>
                        <th style="min-width: 100px;">
                            Last Sent Time
                        </th>

                        <th hidden="true">
                            Created at
                        </th>
                        <th width="150">
                            Last Sent Destination
                        </th>
                        <th style="min-width: 100px;">
                            Last Sent Status
                        </th>
                        <th style="min-width: 180px;">
                            Subject
                        </th>
                        <th style="min-width: 200px;">
                            Filename (.chr)
                        </th>
                        <th style="min-width: 670px;">
                            Content
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $ships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td>
                                <?php echo e($key +  1); ?>

                            </td>
                            <td>
                                <button type="button" class="open-AddBookDialog btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModal"
                                        data-id=<?php echo e($ship->id); ?> data-destination="<?php echo e($ship->last_sent_destination); ?>"
                                        data-subject="<?php echo e($ship->subject); ?>" data-filename="<?php echo e($ship->filename_chr); ?>"
                                        data-content="<?php echo e($ship->content); ?>" data-backdrop="static" data-keyboard="false">
                                    Send Manual
                                </button>
                            </td>
                            <td width="150" style="text-align: center;">
                                <?php echo e(date('d F Y H:i', strtotime($ship->created_at))); ?>

                            </td>
                            <td hidden="true">
                                <?php echo e($ship->created_at); ?>

                            </td>
                            <td width="150">
                                <?php if($ship->last_sent_destination ): ?>

                                    <?php $__currentLoopData = json_decode($ship->last_sent_destination , true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $json): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($json['email'] ?? $json); ?><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td width="150" style="text-align: center;">
                                <?php echo e($ship->last_sent_status ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($ship->subject ?? ''); ?>

                            </td>
                            <td width="150">
                                <?php echo e($ship->filename_chr); ?>

                            </td>
                            <td width="40">
                                <?php echo e($ship->content); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
      </div>
    </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Send Email Manual</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(url('admin/ships/logs')); ?>" enctype="multipart/form-data" id="idForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <span id="noClose"></span>
                        <input type="hidden" name="id" id="id">
                        <div class="form-group">
                            <label for="sin">Last Sent Destination</label>
                            <input class="form-control <?php echo e($errors->has('last_seen_destination') ? 'is-invalid' : ''); ?>"
                                   type="text" name="last_seen_destination" id="last_seen_destination"
                                   value="<?php echo e(old('last_seen_destination', '')); ?>">
                            <?php if($errors->has('last_seen_destination')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('last_seen_destination')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.historyShip.fields.sin_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="sin">Subject</label>
                            <input class="form-control <?php echo e($errors->has('subject') ? 'is-invalid' : ''); ?>" type="text"
                                   name="subject" id="subject" value="<?php echo e(old('subject', '')); ?>">
                            <?php if($errors->has('subject')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('subject')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.historyShip.fields.sin_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="sin">Filename Chr</label>
                            <input class="form-control <?php echo e($errors->has('filename_chr') ? 'is-invalid' : ''); ?>"
                                   type="text" name="filename_chr" id="filename_chr"
                                   value="<?php echo e(old('filename_chr', '')); ?>">
                            <?php if($errors->has('filename_chr')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('filename_chr')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.historyShip.fields.sin_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="sin">Content</label>
                            <input class="form-control <?php echo e($errors->has('content') ? 'is-invalid' : ''); ?>" type="text"
                                   name="content" id="content" value="<?php echo e(old('content', '')); ?>">
                            <?php if($errors->has('content')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('content')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.historyShip.fields.sin_helper')); ?></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Send Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script>
        
    $(document).ready(function() {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            var table = $('#exampleAll').DataTable({ buttons: dtButtons, pageLength: 100, order: [[ 1, 'desc' ]],});
            $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });
            
        setTimeout(function() {
        $('#logs').fadeIn(700);
        }, 500);
        
        $('#exampleAll_wrapper').hide();
  
  
        $('#myInput').change( function() {
        $('#exampleAll_wrapper').show();
            table.search($(this).val()).draw();
        } );

      // Event listener to the two range filtering inputs to redraw on input
      

      /*$('#mois1, #annee1').on('change', function(){
           table.draw();   
        });
      
      $.fn.dataTable.ext.search.push(
        function( settings, data, dataIndex ) {
            var month = parseInt( $('#mois1').val(), 10 );
            var year = parseInt( $('#annee1').val(), 10  );
            var date = data[4].split('-');
            console.log(year)
            if ( ( isNaN( year ) && isNaN( month ) ) ||
                 ( isNaN( month ) && year == date[0] ) ||
                 ( date[1] == month && isNaN( year ) ) ||
                 ( date[1] == month && year == date[0] ) 
                )
            {
                return true;
            }
            return false;
        }
    );*/
    });

    </script>
    <script>

        $(document).on("click", ".open-AddBookDialog", function () {
            var id = $(this).data('id');

            var destination = $(this).data('destination');
            var subject = $(this).data('subject');
            var filename = $(this).data('filename');
            var content = $(this).data('content')

            var data = '';
            for (var n in destination) {
                if(destination[n]['email']) {
                    data = data + destination[n]['email'] + ';'
                }else{
                    data = data + destination[n] + ';'
                }
            }
            $('#last_seen_destination').val(data)
            $('#id').val(id)
            $('#subject').val(subject)
            $('#filename_chr').val(filename)
            $('#content').val(content)
        });

        $("#idForm").submit(function(e) {

            e.preventDefault(); // avoid to execute the actual submit of the form.
            alert('Jangan di close, data lagi dalam proses pengiriman');
            var form = $(this);
            var url = form.attr('action');

            $.ajax({
                type: "POST",
                url: url,
                data: form.serialize(),
                success: function(data)
                {
                    $('#exampleModal').modal('hide')
                    console.log(data)

                    if(!alert('Data Sudah Terkirim')){window.location.reload();}
                    $('#noClose').html('');
                }
            });


        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/skysatcotest/skysentana/resources/views/admin/ships/logs.blade.php ENDPATH**/ ?>