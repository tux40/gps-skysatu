
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.user.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.users.update", [$user->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name"><?php echo e(trans('cruds.user.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="username"><?php echo e(trans('cruds.user.fields.username')); ?></label>
                <input class="form-control <?php echo e($errors->has('username') ? 'is-invalid' : ''); ?>" type="text" name="username" id="username" value="<?php echo e(old('username', $user->username)); ?>" required>
                <?php if($errors->has('username')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('username')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.username_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="password"><?php echo e(trans('cruds.user.fields.password')); ?></label>
                <input class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" type="password" name="password" id="password">
                <?php if($errors->has('password')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('password')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.password_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="roles"><?php echo e(trans('cruds.user.fields.roles')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('roles') ? 'is-invalid' : ''); ?>" name="roles[]" id="roles" multiple required>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('roles', [])) || $user->roles->contains($id)) ? 'selected' : ''); ?>><?php echo e($roles); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('roles')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('roles')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.roles_helper')); ?></span>
            </div>
            <!--<div class="form-group">
                <label for="terminals"><?php echo e(trans('cruds.user.fields.terminal')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('terminals') ? 'is-invalid' : ''); ?>" name="terminals[]" id="terminals" multiple>
                    <?php $__currentLoopData = $terminals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $terminal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('terminals', [])) || $user->terminals->contains($id)) ? 'selected' : ''); ?>><?php echo e($id .' - '.$terminal); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('terminals')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('terminals')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.terminal_helper')); ?></span>
            </div>-->
            <div class="form-group">
                <label for="ships"><?php echo e(trans('cruds.user.fields.ship')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('ships') ? 'is-invalid' : ''); ?>" name="ships[]" id="terminals" multiple >

                    <?php $__currentLoopData = $ships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($ship->id); ?>" <?php echo e((in_array($ship->id, old('ships', [])) || $user->ships->contains($ship->id)) ? 'selected' : ''); ?>><?php echo e($ship->ship_ids.' - '.$ship->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('ships')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('ships')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.ship_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="email"><?php echo e(trans('cruds.user.fields.destinasion-email')); ?></label>
                <?php $i = 0; ?>
                <?php if(count($user->email) != ""): ?>
                <?php $__currentLoopData = $user->email; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="clone-email">
                    <div class="form-inline">
                        <input class="form-control col-md-8 <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>"
                               type="email" name="email[]" id="email" value="<?php echo e(old('email[]', $email->email)); ?>">
                        <span class="col-md-1"></span>
                        <div class="btn btn-warning col-md-2 delete-clone-email" <?php if($i == 0): ?> style="display: none" <?php endif; ?>>- Delete Email</div>
                    </div>
                    <?php if($errors->has('email')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('email')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.user.fields.roles_helper')); ?></span>
                    <br>
                </div>
                    <?php $i++ ;?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="clone-email">
                    <div class="form-inline">
                        <input class="form-control col-md-8 <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>"
                               type="email" name="email[]" id="email">
                        <span class="col-md-1"></span>
                        <div class="btn btn-warning col-md-2 delete-clone-email" <?php if($i == 0): ?> style="display: none" <?php endif; ?>>- Delete Email</div>
                    </div>
                    <?php if($errors->has('email')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('email')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.user.fields.roles_helper')); ?></span>
                    <br>
                </div>
                    <?php $i++ ;?>
                <?php endif; ?>
                <span class="clone-last"></span>
            </div>
            <!--<div class="form-group">
                <div class="btn btn-info add-clone-email">+ Add New Email</div>
            </div>-->
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var count = <?php echo e($i ? $i : 1); ?>;
        $(document).ready(function () {
            $(".add-clone-email").on('click', function () {
                if(count >= 9 ){
                    $(".add-clone-email").hide();
                }

                var clone = $('.clone-email:last').clone();
                // clone.removeClass('clone-email').addClass('clone-email'+count);
                clone.find("#email").attr({ name: "email[]"});
                clone.find("#email").val("");
                clone.find(".delete-clone-email").show();
                clone.appendTo('.clone-last');
                count++;
            });
        });

        $(document).on('click', ".delete-clone-email", function () {
            $(this).closest(".clone-email").remove();
            count--;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/skysatcotest/skysentana/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>