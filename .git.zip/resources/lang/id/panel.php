<?php

return [
    'site_title' => 'SkySatu',
];
