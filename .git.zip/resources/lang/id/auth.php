<?php

return [
    'failed'   => 'Email atau Password anda salah, silakan coba lagi!',
    'throttle' => 'Terlalu banyak percobaan login, tolong login setelah   :seconds detik',
];
