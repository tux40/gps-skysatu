<?php

return [
    'site_title' => 'Sky1MAS',
    'site_subtitle' => 'Monitoring & Alert System',
];
